<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
#app {
  margin: 0;
  p{margin: 0;}
}
</style>
